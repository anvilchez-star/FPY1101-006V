productos = {
    'M001': ['Alimento Premium', 'comida', 'DogPlus', 10.0, True, False],
    'M002': ['Arena Aglomerante', 'higiene', 'CatClean', 8.0, False, False],
    'M003': ['Snack Dental', 'snack', 'BiteJoy', 1.0, True, True],
    'M004': ['Shampoo Suave', 'higiene', 'PetCare', 0.5, False, True],
    'M005': ['Correa Nylon', 'accesorio', 'WalkPro', 0.3, True, False],
    'M006': ['Cama Mediana', 'accesorio', 'CozyPet', 2.0, False, False]
}

stock = {
    'M001': [32990, 12],
    'M002': [9990, 0],
    'M003': [5490, 25],
    'M004': [7990, 5],
    'M005': [11990, 7],
    'M006': [24990, 3]
}


def unidades_categoria(categoria):
    """
    Suma las unidades en stock de todos los productos pertenecientes 
    a la categoría indicada (sin distinguir mayúsculas/minúsculas).
    """
    total_unidades = 0
    categoria_buscar = categoria.strip().lower()
    
    for cod, datos in productos.items():
        cat_producto = datos[1].strip().lower()
        if cat_producto == categoria_buscar:
            total_unidades += stock[cod][1]
            
    print(f"El total de unidades disponibles es: {total_unidades}")


def busqueda_precio(p_min, p_max):
    """
    Muestra productos dentro del rango de precio y con stock disponible (>0),
    ordenados alfabéticamente por nombre con el formato 'Nombre--Código'.
    """
    resultados = []
    for cod, datos_stock in stock.items():
        precio = datos_stock[0]
        unidades = datos_stock[1]
        
        if p_min <= precio <= p_max and unidades > 0:
            nombre = productos[cod][0]
            resultados.append(f"{nombre}--{cod}")
            
    if resultados:
        resultados.sort()
        print(f"Los productos encontrados son: {resultados}")
    else:
        print("No hay productos en ese rango de precios.")


def actualizar_precio(codigo, nuevo_precio):
    """
    Actualiza el precio del producto si el código existe (case-insensitive).
    Retorna True si tiene éxito, False en caso contrario.
    """
    codigo_upper = codigo.strip().upper()
    if codigo_upper in stock:
        stock[codigo_upper][0] = nuevo_precio
        return True
    return False


def eliminar_producto(codigo):
    """
    Elimina un producto de ambos diccionarios si el código existe (case-insensitive).
    Retorna True si tiene éxito, False en caso contrario.
    """
    codigo_upper = codigo.strip().upper()
    if codigo_upper in productos and codigo_upper in stock:
        del productos[codigo_upper]
        del stock[codigo_upper]
        return True
    return False


def agregar_producto(codigo, nombre, categoria, marca, peso_kg, es_importado, es_para_cachorro, precio, unidades):
    """
    Agrega de forma efectiva el producto a los diccionarios si no existe previamente.
    Retorna True si tiene éxito, False si el código ya existe.
    """
    codigo_upper = codigo.strip().upper()
    if codigo_upper in productos or codigo_upper in stock:
        return False
        
    productos[codigo_upper] = [
        nombre.strip(),
        categoria.strip().lower(), 
        marca.strip(),
        peso_kg,
        es_importado,
        es_para_cachorro
    ]
    stock[codigo_upper] = [precio, unidades]
    return True


def validar_codigo(codigo):
    if not codigo or codigo.isspace():
        return False
    if codigo.strip().upper() in productos:
        return False
    return True

def validar_nombre(nombre):
    return bool(nombre and not nombre.isspace())

def validar_categoria(categoria):
    return bool(categoria and not categoria.isspace())

def validar_marca(marca):
    return bool(marca and not marca.isspace())

def validar_peso(peso_str):
    try:
        peso = float(peso_str)
        return peso > 0
    except ValueError:
        return False

def validar_es_importado(opcion):
    return opcion.strip().lower() in ['s', 'n']

def validar_es_para_cachorro(opcion):
    return opcion.strip().lower() in ['s', 'n']

def validar_precio(precio_str):
    try:
        precio = int(precio_str)
        return precio > 0
    except ValueError:
        return False

def validar_unidades(unidades_str):
    try:
        unidades = int(unidades_str)
        return unidades >= 0
    except ValueError:
        return False



def menu_principal():
    while True:
        print("\n========== MENÚ PRINCIPAL ==========")
        print("1. Unidades por categoría")
        print("2. Búsqueda de productos por rango de precio")
        print("3. Actualizar precio de producto")
        print("4. Agregar producto")
        print("5. Eliminar producto")
        print("6. Salir")
        print("=====================================")
        
        opcion = input("Ingrese opción: ").strip()
        
        if opcion == '1':
            cat = input("Ingrese categoría a consultar: ")
            unidades_categoria(cat)
            
        elif opcion == '2':
            while True:
                try:
                    p_min_input = input("Ingrese precio mínimo: ")
                    p_min = int(p_min_input)
                    p_max_input = input("Ingrese precio máximo: ")
                    p_max = int(p_max_input)
                    
                    # Validaciones lógicas adicionales requeridas por el enunciado
                    if p_min >= 0 and p_max >= 0 and p_min <= p_max:
                        busqueda_precio(p_min, p_max)
                        break
                    else:
                        print("El precio mínimo debe ser menor o igual al máximo y ambos no negativos.")
                except ValueError:
                    print("Debe ingresar valores enteros")
                    
        elif opcion == '3':
            while True:
                cod = input("Ingrese código del producto: ")
                nuevo_precio_str = input("Ingrese nuevo precio: ")
                
                if nuevo_precio_str.isdigit() and int(nuevo_precio_str) > 0:
                    nuevo_precio = int(nuevo_precio_str)
                    exito = actualizar_precio(cod, nuevo_precio)
                    if exito:
                        print("Precio actualizado")
                    else:
                        print("El código no existe")
                else:
                    print("El precio debe ser un número entero positivo.")
                
                repetir = input("¿Desea actualizar otro precio (s/n)?: ").strip().lower()
                if repetir != 's':
                    break
                    
        elif opcion == '4':
            cod_in = input("Ingrese código del producto: ")
            nom_in = input("Ingrese nombre: ")
            cat_in = input("Ingrese categoría: ")
            mar_in = input("Ingrese marca: ")
            peso_in = input("Ingrese peso (kg): ")
            imp_in = input("¿Es importado? (s/n): ")
            cach_in = input("¿Es para cachorro? (s/n): ")
            prec_in = input("Ingrese precio: ")
            unid_in = input("Ingrese unidades: ")
            
            if not validar_codigo(cod_in):
                print("Error: El código no es válido o ya existe.")
                continue
            if not validar_nombre(nom_in):
                print("Error: El nombre no puede estar vacío.")
                continue
            if not validar_categoria(cat_in):
                print("Error: La categoría no puede estar vacía.")
                continue
            if not validar_marca(mar_in):
                print("Error: La marca no puede estar vacía.")
                continue
            if not validar_peso(peso_in):
                print("Error: El peso debe ser un número decimal o entero mayor que cero.")
                continue
            if not validar_es_importado(imp_in):
                print("Error: Para la importación debe ingresar únicamente 's' o 'n'.")
                continue
            if not validar_es_para_cachorro(cach_in):
                print("Error: Para la opción de cachorro debe ingresar únicamente 's' o 'n'.")
                continue
            if not validar_precio(prec_in):
                print("Error: El precio debe ser un entero positivo mayor que cero.")
                continue
            if not validar_unidades(unid_in):
                print("Error: Las unidades deben ser un entero mayor o igual a cero.")
                continue
            
            peso_kg = float(peso_in)
            es_importado = True if imp_in.strip().lower() == 's' else False
            es_para_cachorro = True if cach_in.strip().lower() == 's' else False
            precio = int(prec_in)
            unidades = int(unid_in)
            
            agregado = agregar_producto(
                cod_in, nom_in, cat_in, mar_in, peso_kg, 
                es_importado, es_para_cachorro, precio, unidades
            )
            if agregado:
                print("Producto agregado")
            else:
                print("El código ya existe")
                
        elif opcion == '5':
            cod = input("Ingrese el código del producto que desea eliminar: ")
            exito = eliminar_producto(cod)
            if exito:
                print("Producto eliminado")
            else:
                print("El código no existe")
                
        elif opcion == '6':
            print("Programa finalizado.")
            break
            
        else:
            print("Debe seleccionar una opción válida")

if __name__ == "__main__":
    menu_principal()